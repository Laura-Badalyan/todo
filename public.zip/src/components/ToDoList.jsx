const ToDoList = (props) => {
    const removeItem = function(index) {
        // e.preventDefault();
        //
    }

    console.log(props.todos);
    return (
        <div className="ToDoList">
            {
                props.todos.map((item, index) => {
                    return (
                        <div key={item.id} className="ToDoList-item">
                            <label>
                                <input type="checkbox" onChange={(e)=> {
                                    item.isChecked = true;
                                    e.target.checked = true;
                                }}/>
                                <span>{item.text}</span>
                            </label>
                            <button onClick={() => {
                                props.todos = props.todos.filter(() => {})
                                console.log(props.todos)
                            }}>X</button>
                        </div>
                    )
                })

            }
        </div>)
};

export default ToDoList;